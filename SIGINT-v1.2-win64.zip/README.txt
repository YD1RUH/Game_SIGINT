﻿Game SIGINT v1.2 - Octacons / YD1RUH

Run SIGINT.exe.
Requires 64-bit Windows 10/11 and the Microsoft Edge WebView2 Runtime.
The executable is not code-signed, so Windows SmartScreen may show a warning.
All operations, agencies, satellites and data in this game are fictional.
